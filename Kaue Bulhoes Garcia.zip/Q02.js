for (let i = 1; i <= 4; i++) {
    for (let j = 1; j <= i; j++) {
        console.log(j);
    }
}

/**Q02 - B
O código forma uma matriz, com um loop externo fator "i" e um interno fator "j", cada iteração aumentará o contador "j" em 1 e irá sair de "j" para "i" quando "j" for menor ou igual a 1. */